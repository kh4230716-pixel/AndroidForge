package com.loshermanos.panel;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.*;
import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {
    private TextView status;
    private static final int REQUEST_SHIZUKU = 4101;

    private final Shizuku.OnRequestPermissionResultListener permissionListener =
            (requestCode, grantResult) -> {
                if (requestCode == REQUEST_SHIZUKU) updateStatus();
            };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        Shizuku.addRequestPermissionResultListener(permissionListener);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(28, 28, 28, 28);
        root.setBackgroundColor(Color.rgb(18,17,29));

        TextView title = new TextView(this);
        title.setText("LOS HERMANOS"); title.setTextColor(Color.rgb(166,103,255));
        title.setTextSize(27); title.setGravity(Gravity.CENTER); root.addView(title);
        TextView subtitle = new TextView(this);
        subtitle.setText("Painel flutuante • Android 15"); subtitle.setTextColor(Color.WHITE);
        subtitle.setPadding(0,20,0,20); root.addView(subtitle);

        status = new TextView(this); status.setTextColor(Color.rgb(65,230,166));
        status.setGravity(Gravity.CENTER); status.setPadding(0,8,0,18); root.addView(status);

        Button shizuku = new Button(this); shizuku.setText("CONECTAR / AUTORIZAR SHIZUKU"); root.addView(shizuku);
        shizuku.setOnClickListener(v -> requestShizuku());
        Button overlay = new Button(this); overlay.setText("PERMITIR SOBREPOSIÇÃO"); root.addView(overlay);
        overlay.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())));
            } else Toast.makeText(this, "Sobreposição já autorizada", Toast.LENGTH_SHORT).show();
        });
        Button start = new Button(this); start.setText("ABRIR PAINEL FLUTUANTE"); root.addView(start);
        start.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())));
            } else { startService(new Intent(this, OverlayService.class)); }
        });
        setContentView(root);
        updateStatus();
    }

    private void requestShizuku() {
        if (!Shizuku.pingBinder()) {
            Toast.makeText(this, "Shizuku não está ativo. Abra o Shizuku e inicie o serviço.", Toast.LENGTH_LONG).show();
            updateStatus(); return;
        }
        if (Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Shizuku já autorizado", Toast.LENGTH_SHORT).show();
        } else if (Shizuku.shouldShowRequestPermissionRationale()) {
            Shizuku.requestPermission(REQUEST_SHIZUKU);
        } else {
            Shizuku.requestPermission(REQUEST_SHIZUKU);
        }
        updateStatus();
    }

    private void updateStatus() {
        if (status == null) return;
        boolean running = Shizuku.pingBinder();
        boolean granted = running && Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED;
        status.setText("Shizuku: " + (running ? (granted ? "conectado e autorizado" : "ativo • aguardando autorização") : "não conectado")
                + "\nSobreposição: " + (Settings.canDrawOverlays(this) ? "autorizada" : "pendente"));
    }

    @Override protected void onResume() { super.onResume(); updateStatus(); }
    @Override protected void onDestroy() { Shizuku.removeRequestPermissionResultListener(permissionListener); super.onDestroy(); }
}
