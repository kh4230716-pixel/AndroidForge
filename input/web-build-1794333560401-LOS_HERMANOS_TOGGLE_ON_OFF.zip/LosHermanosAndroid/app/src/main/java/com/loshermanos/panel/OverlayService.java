package com.loshermanos.panel;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.util.HashMap;
import java.util.Map;

public class OverlayService extends Service {
    private WindowManager wm;
    private View panel;
    private TextView bubble;
    private WindowManager.LayoutParams panelParams;
    private WindowManager.LayoutParams bubbleParams;
    private final int purple = Color.rgb(166, 103, 255);
    private final int green = Color.rgb(65, 230, 166);
    private final int muted = Color.rgb(178, 180, 199);
    // Estados visuais mantidos enquanto o painel vira bolinha e volta.
    private final Map<String, Boolean> optionStates = new HashMap<>();
    private String selectedAimTarget = "";

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        int type = Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        panelParams = new WindowManager.LayoutParams(
                dp(290), WindowManager.LayoutParams.WRAP_CONTENT, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        panelParams.gravity = Gravity.TOP | Gravity.START;
        panelParams.x = dp(18);
        panelParams.y = dp(90);

        bubbleParams = new WindowManager.LayoutParams(
                dp(58), dp(58), type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        bubbleParams.gravity = Gravity.TOP | Gravity.START;
        bubbleParams.x = dp(18);
        bubbleParams.y = dp(140);

        createPanel();
        wm.addView(panel, panelParams);
    }

    private void createPanel() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(12), dp(14), dp(12));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.rgb(18, 17, 29));
        bg.setCornerRadius(dp(18));
        bg.setStroke(dp(1), Color.rgb(92, 62, 135));
        card.setBackground(bg);
        card.setElevation(dp(12));

        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = new TextView(this);
        title.setText("LOS HERMANOS");
        title.setTextColor(purple);
        title.setTextSize(17);
        title.setTypeface(null, Typeface.BOLD);
        head.addView(title, new LinearLayout.LayoutParams(0, -2, 1));

        TextView drag = new TextView(this);
        drag.setText("MOVER");
        drag.setTextColor(muted);
        drag.setTextSize(10);
        drag.setPadding(dp(8), dp(5), dp(4), dp(5));
        head.addView(drag);
        card.addView(head);
        attachDrag(drag, panelParams, panel);

        TextView sub = new TextView(this);
        sub.setText("PAINEL DE DEMONSTRAÇÃO");
        sub.setTextColor(muted);
        sub.setTextSize(9);
        sub.setPadding(0, dp(3), 0, dp(10));
        card.addView(sub);

        section(card, "ESP");
        addOption(card, "ESP Linha");
        addOption(card, "ESP Esqueleto");
        addOption(card, "ESP Vida");
        addOption(card, "ESP Quadrado");
        section(card, "AIMBOT  •  VISUAL");
        addAimTarget(card, "Pescoço");
        addAimTarget(card, "Cabeça");
        addAimTarget(card, "Peito");
        addOption(card, "Aim Lock");

        TextView minimize = new TextView(this);
        minimize.setText("MINIMIZAR PARA BOLINHA   −");
        minimize.setTextColor(Color.WHITE);
        minimize.setTextSize(11);
        minimize.setGravity(Gravity.CENTER);
        GradientDrawable mb = new GradientDrawable();
        mb.setColor(Color.rgb(83, 39, 75));
        mb.setCornerRadius(dp(10));
        minimize.setBackground(mb);
        minimize.setPadding(dp(8), 0, dp(8), 0);
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(-1, dp(42));
        mp.setMargins(0, dp(10), 0, 0);
        card.addView(minimize, mp);
        minimize.setOnClickListener(v -> minimizePanel());
        panel = card;
    }

    private void createBubble() {
        bubble = new TextView(this);
        bubble.setText("LH");
        bubble.setTextColor(Color.WHITE);
        bubble.setTextSize(17);
        bubble.setTypeface(null, Typeface.BOLD);
        bubble.setGravity(Gravity.CENTER);
        GradientDrawable circle = new GradientDrawable();
        circle.setShape(GradientDrawable.OVAL);
        circle.setColor(Color.rgb(105, 42, 160));
        circle.setStroke(dp(2), green);
        bubble.setBackground(circle);
        bubble.setElevation(dp(10));

        bubble.setOnTouchListener(new View.OnTouchListener() {
            private int startX, startY;
            private float downX, downY;
            private boolean moved;

            @Override
            public boolean onTouch(View view, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = bubbleParams.x;
                        startY = bubbleParams.y;
                        downX = event.getRawX();
                        downY = event.getRawY();
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        int dx = (int) (event.getRawX() - downX);
                        int dy = (int) (event.getRawY() - downY);
                        if (Math.abs(dx) > dp(5) || Math.abs(dy) > dp(5)) moved = true;
                        bubbleParams.x = startX + dx;
                        bubbleParams.y = startY + dy;
                        try { wm.updateViewLayout(bubble, bubbleParams); } catch (Exception ignored) {}
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) restorePanel();
                        return true;
                }
                return true;
            }
        });
    }

    private void minimizePanel() {
        if (panel == null) return;
        try { wm.removeView(panel); } catch (Exception ignored) {}
        panel = null;
        createBubble();
        wm.addView(bubble, bubbleParams);
    }

    private void restorePanel() {
        if (bubble != null) {
            try { wm.removeView(bubble); } catch (Exception ignored) {}
            bubble = null;
        }
        if (panel == null) createPanel();
        wm.addView(panel, panelParams);
    }

    private void attachDrag(View handle, WindowManager.LayoutParams params, View target) {
        handle.setOnTouchListener(new View.OnTouchListener() {
            private int startX, startY;
            private float downX, downY;
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    startX = params.x;
                    startY = params.y;
                    downX = event.getRawX();
                    downY = event.getRawY();
                    return true;
                }
                if (event.getAction() == MotionEvent.ACTION_MOVE) {
                    params.x = startX + (int) (event.getRawX() - downX);
                    params.y = startY + (int) (event.getRawY() - downY);
                    try { wm.updateViewLayout(target, params); } catch (Exception ignored) {}
                    return true;
                }
                return event.getAction() == MotionEvent.ACTION_UP;
            }
        });
    }

    private void section(LinearLayout container, String label) {
        TextView text = new TextView(this);
        text.setText(label);
        text.setTextColor(green);
        text.setTextSize(11);
        text.setTypeface(null, Typeface.BOLD);
        text.setPadding(0, dp(8), 0, dp(5));
        container.addView(text);
    }

    private GradientDrawable optionBackground(boolean enabled, boolean selected) {
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(enabled || selected ? Color.rgb(43, 66, 57) : Color.rgb(37, 32, 52));
        shape.setCornerRadius(dp(9));
        shape.setStroke(dp(1), enabled || selected ? green : Color.rgb(77, 61, 103));
        return shape;
    }

    private void addOption(LinearLayout container, String label) {
        TextView option = new TextView(this);
        option.setTextSize(12);
        option.setGravity(Gravity.CENTER_VERTICAL);
        option.setPadding(dp(12), 0, dp(10), 0);
        boolean enabled = Boolean.TRUE.equals(optionStates.get(label));
        option.setText(label + (enabled ? "     ● ON" : "     ○ OFF"));
        option.setTextColor(enabled ? green : Color.rgb(235, 231, 245));
        option.setBackground(optionBackground(enabled, false));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(37));
        lp.setMargins(0, dp(3), 0, dp(3));
        container.addView(option, lp);
        option.setOnClickListener(v -> {
            boolean next = !Boolean.TRUE.equals(optionStates.get(label));
            optionStates.put(label, next);
            option.setText(label + (next ? "     ● ON" : "     ○ OFF"));
            option.setTextColor(next ? green : Color.rgb(235, 231, 245));
            option.setBackground(optionBackground(next, false));
            Toast.makeText(this, label + (next ? " ativado" : " desativado") + " (demonstração)", Toast.LENGTH_SHORT).show();
        });
    }

    private void addAimTarget(LinearLayout container, String target) {
        String key = "Alvo: " + target;
        TextView option = new TextView(this);
        option.setTextSize(12);
        option.setGravity(Gravity.CENTER_VERTICAL);
        option.setPadding(dp(12), 0, dp(10), 0);
        boolean selected = target.equals(selectedAimTarget);
        option.setText((selected ? "✓  " : "○  ") + key + (selected ? "   SELECIONADO" : ""));
        option.setTextColor(selected ? green : Color.rgb(235, 231, 245));
        option.setBackground(optionBackground(false, selected));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(37));
        lp.setMargins(0, dp(3), 0, dp(3));
        container.addView(option, lp);
        option.setOnClickListener(v -> {
            selectedAimTarget = target;
            Toast.makeText(this, key + " selecionado (demonstração)", Toast.LENGTH_SHORT).show();
            refreshPanel();
        });
    }

    private void refreshPanel() {
        // Reconstrói a interface mantendo optionStates e selectedAimTarget no serviço.
        if (panel != null) {
            try { wm.removeView(panel); } catch (Exception ignored) {}
        }
        createPanel();
        wm.addView(panel, panelParams);
    }

    @Override
    public void onDestroy() {
        if (panel != null) try { wm.removeView(panel); } catch (Exception ignored) {}
        if (bubble != null) try { wm.removeView(bubble); } catch (Exception ignored) {}
        panel = null;
        bubble = null;
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
