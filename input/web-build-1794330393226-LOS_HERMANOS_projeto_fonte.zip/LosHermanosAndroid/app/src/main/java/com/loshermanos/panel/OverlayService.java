package com.loshermanos.panel;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class OverlayService extends Service {
    private WindowManager wm;
    private View panel;
    private WindowManager.LayoutParams params;

    @Override public void onCreate() {
        super.onCreate();
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        int type = android.os.Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(14, 10, 14, 12);
        box.setBackgroundColor(Color.rgb(22, 18, 32));

        TextView header = new TextView(this);
        header.setText("LOS HERMANOS     [ARRASTE AQUI]");
        header.setTextColor(Color.rgb(190, 120, 255));
        header.setTextSize(16);
        header.setPadding(4, 8, 4, 12);
        box.addView(header);

        addSection(box, "ESP");
        addDemoButton(box, "ESP Linha");
        addDemoButton(box, "ESP Esqueleto");
        addDemoButton(box, "ESP Vida");
        addDemoButton(box, "ESP Quadrado");

        addSection(box, "AIMBOT — DEMONSTRAÇÃO");
        addDemoButton(box, "Selecionar: Pescoço");
        addDemoButton(box, "Selecionar: Cabeça");
        addDemoButton(box, "Selecionar: Peito");
        addDemoButton(box, "Aim Lock (visual)");

        Button close = new Button(this);
        close.setText("FECHAR PAINEL");
        box.addView(close);
        close.setOnClickListener(v -> stopSelf());

        params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 30; params.y = 120;

        header.setOnTouchListener(new View.OnTouchListener() {
            int startX, startY; float downX, downY;
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    startX = params.x; startY = params.y;
                    downX = e.getRawX(); downY = e.getRawY(); return true;
                }
                if (e.getAction() == MotionEvent.ACTION_MOVE) {
                    params.x = startX + (int)(e.getRawX() - downX);
                    params.y = startY + (int)(e.getRawY() - downY);
                    wm.updateViewLayout(panel, params); return true;
                }
                return e.getAction() == MotionEvent.ACTION_UP;
            }
        });

        panel = box;
        wm.addView(panel, params);
    }

    private void addSection(LinearLayout box, String text) {
        TextView t = new TextView(this);
        t.setText(text); t.setTextColor(Color.rgb(90, 235, 160));
        t.setTextSize(14); t.setPadding(4, 10, 4, 4);
        box.addView(t);
    }
    private void addDemoButton(LinearLayout box, String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(11);
        box.addView(b);
        b.setOnClickListener(v -> Toast.makeText(this,
                label + " — modo demonstrativo", Toast.LENGTH_SHORT).show());
    }
    @Override public void onDestroy() {
        if (panel != null) { try { wm.removeView(panel); } catch (Exception ignored) {} }
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
