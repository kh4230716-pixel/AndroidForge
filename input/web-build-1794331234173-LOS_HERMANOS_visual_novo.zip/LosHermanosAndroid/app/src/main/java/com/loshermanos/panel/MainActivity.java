package com.loshermanos.panel;
import android.app.Activity; import android.content.*; import android.net.Uri; import android.os.*; import android.provider.Settings; import android.graphics.Color; import android.view.Gravity; import android.widget.*;
public class MainActivity extends Activity {
 public void onCreate(Bundle b){super.onCreate(b); LinearLayout l=new LinearLayout(this); l.setOrientation(1); l.setGravity(Gravity.CENTER); l.setPadding(28,28,28,28); l.setBackgroundColor(Color.rgb(18,17,29));
 TextView t=new TextView(this); t.setText("LOS HERMANOS"); t.setTextColor(Color.rgb(166,103,255)); t.setTextSize(27); t.setGravity(Gravity.CENTER); l.addView(t);
 TextView s=new TextView(this); s.setText("Painel flutuante demonstrativo"); s.setTextColor(Color.WHITE); s.setPadding(0,24,0,24); l.addView(s);
 Button a=new Button(this); a.setText("ATIVAR PAINEL"); l.addView(a); a.setOnClickListener(v->{if(Build.VERSION.SDK_INT>=23&&!Settings.canDrawOverlays(this)){startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName())));}else{startService(new Intent(this,OverlayService.class));finish();}}); setContentView(l);}
}
